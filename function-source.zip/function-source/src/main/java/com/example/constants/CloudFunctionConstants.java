package com.example.constants;

public final class CloudFunctionConstants {


    public static String SCOPE = "https://www.googleapis.com/auth/cloud-platform";
    public static String INPUT_FILE = "inputFile";
    public static String SUCCESS_MESSAGE = "Cloud function executed successfully";



}
